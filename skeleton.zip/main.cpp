
#include <iostream>
#include "tarifa.hpp"
#include "ugyfel.hpp"
#include <fstream>
#include <string>
#include <sstream>
#include "fgv.h"

#include "memtrace.h"
void felszab(lista* kezdo)// felszabaditja a listat
{
	lista *iter = kezdo;
	while (iter != NULL)
	{
		lista* temp = iter->kov;
		delete iter->fo;
		delete iter;
		iter = temp;
	}
}
void beolvasteszt(lista* kezd)//teszteli a beolvasas eredmenyet, az elso 2 ugyfelre
{
	std::cout << "beolvas teszt" << std::endl;
	//nev vizsgalat
	std::string a= "Kis_Pista";
	if (!a.compare(kezd->fo->get_nev()))
		std::cout << "sikeres1/0" << std::endl;
	else  std::cout << "sikertelen1/0_nev"; 

	//cim vizsgalat
	a = "Nagy_Lajos_utca_12";
	if (!a.compare(kezd->fo->get_cim()))
		std::cout << "sikeres1/1" << std::endl;
	else  std::cout << "sikertelen1/1_cim"; 

	//telefonszam vizsgalat
	int tel= 201234567;
	if (tel == kezd->fo->get_tel())
		std::cout << "sikeres 1/2" << std::endl;
	else std::cout << "sikertelen 1/1_tel";


	//nev teszt
	a = "Nagy_Pista";
	if (!a.compare(kezd->kov->fo->get_nev()))
		std::cout << "sikeres 2/0" << std::endl;
	else std::cout << "sikertelen 2/0_nev" << std::endl;

	//cim teszt
	a = "Bp_Nagy_Lajos_kiraly_utja_8/b";
	if (!a.compare(kezd->kov->fo->get_cim()))
		std::cout << "sikeres 2/1" << std::endl;
	else  std::cout << "sikertelen2/1_cim";

	//telefonszam vizsgalat
	tel = 202020202;
	if (tel == kezd->kov->fo->get_tel())
		std::cout << "sikeres 2/2" << std::endl;
	else std::cout << "sikertelen 2/2_tel";
	

}
void sumteszt(lista* kezdo)//teszteli a szamla kiszamito mukodeset
{
	if (4530 == sum(kezdo))
		std::cout << "sikeres sum1" << std::endl;
	else std::cout << "sikertelen sum1" << std::endl;
	if (6000 == sum(kezdo->kov))
		std::cout << "sikeres sum2" << std::endl;
	else std::cout << "sikertelen sum1" << std::endl;
}
//alap: 6000, 100perc,  50 sms, 1000mb net, ut�na 50ft/perc 50/sms 4ft/MB
//net 6000  0 perc, 0 sms,korl�tlan net, ut�na 55/perc 55/sms	0mb/ft
//sms:4500Ft, 45 perc, 100 sms, 0mb, ut�na,  55/perc 30/sms 6/MB
int main()
{
	lista * kezd = NULL;
	tarifa* alap = new tarifa(6000, 100, 50, 1000, 50, 50, 4);
	tarifa* net = new tarifa(6000, 0, 0, 0, 55, 55, 0);
	tarifa* sms = new tarifa(4500, 45, 100, 0, 55, 30, 6);
	kezd=olvas(kezd, alap, net, sms);
	kiir(kezd->kov);
	beolvasteszt(kezd);
	sumteszt(kezd);
	felszab(kezd);
	delete alap;
	delete net;
	delete sms;
	std::cin.get();
	return 0;
}