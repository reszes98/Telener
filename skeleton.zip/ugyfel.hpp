#pragma once
#include <string>
class ugyfel{
	int tel;
	std::string nev;
	std::string cim;
	unsigned int usdmin;//felhasznalt percek
	unsigned int usdsms;//felhasznalt smsek
	unsigned int usdmb;//felhasznalt mb
public:

	//konst �s dek
	ugyfel(int tel=0, std::string nev=" ", std::string cim=" ", unsigned int usdmin=0, unsigned int usdsms=0, unsigned int usdmb=0)
		:tel(tel),  nev(nev), cim(cim), usdmin(usdmin),  usdsms(usdsms), usdmb(usdmb) {}
	~ugyfel() {}

	// getterek
	int get_tel() { return tel; }
	std::string& get_nev() { return nev; }
	std::string& get_cim() { return cim; }
	unsigned int get_usdmin() { return usdmin; }
	unsigned int get_usdsms() { return usdsms; }
	unsigned int get_usdmb() { return usdmb; }

	//setterek
	void set_tel(int p) { tel = p; }
	void set_nev(std::string p) { nev = p; }
	void set_cim(std::string p) { cim = p; }
	void set_usdmin(unsigned int p) { usdmin = p; }
	void set_usdsms(unsigned int p) { usdsms = p; }
	void set_usdmb(unsigned int p) { usdmb = p; }
};