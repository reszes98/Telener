#include "fgv.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
lista* beszur(lista* kezdo, lista*uj)//a lancolt listaba beszurja a felhasznalokat( a vegere)
{
	lista* temp;
	if (kezdo == NULL)
	{
		kezdo = uj;
	}
	else
	{
		for (temp = kezdo; temp->kov != NULL; temp = temp->kov);
		temp->kov = uj;
		uj->kov = NULL;
	}
	return kezdo;
}
lista* keres(lista* kezdo, int keresett)// a lancolt listaban keres telefonszam alapjan
{
	lista* temp;
	for (temp = kezdo; temp != NULL; temp = temp->kov)
	{
		if (temp->fo->get_tel() == keresett)
			return temp;
	}
	return NULL;
}
int sum(lista* a)//a szamla vegosszeget szamitja ki
{
	int sum = a->tar->get_dij();
	if (a->fo->get_usdmin() > a->tar->get_min())
		sum += (a->fo->get_usdmin() - a->tar->get_min())*a->tar->get_pmin();
	if (a->fo->get_usdsms() > a->tar->get_sms())
		sum += (a->fo->get_usdsms() - a->tar->get_sms())*a->tar->get_psms();
	if (a->fo->get_usdmb() > a->tar->get_mb())
		sum += (a->fo->get_usdmb() - a->tar->get_mb())*a->tar->get_pmb();
	return sum;
}
void kiir(lista* a) //pointerrel megadott ugyfel adatait irja ki a standard bemenetre
{
	std::cout << "nev: " << a->fo->get_nev() << std::endl;
	std::cout << "cim: " << a->fo->get_cim() << std::endl;
	std::cout << "alapdij: " << a->tar->get_dij() << std::endl;
	std::cout << "felhasznalt percek/ingyenes: " << a->fo->get_usdmin() << "/" << a->tar->get_min() << std::endl;
	std::cout << "felhasznalt smsek/ingyenes: " << a->fo->get_usdsms() << "/" << a->tar->get_sms() << std::endl;
	std::cout << "felhasznalt MB-ok/ingyenes: " << a->fo->get_usdmb() << "/" << a->tar->get_mb() << std::endl;
	std::cout << "Szamla osszege: " << sum(a) << "Ft" << std::endl;
}
lista* olvas(lista* kezd, tarifa* alap, tarifa* net, tarifa* sms)//filebol olvassa be az ugyfeleket
{
	std::ifstream file("ugyfel.txt");
	std::string dij, nev, cim, line;
	int tel;
	unsigned int usdmin, usdsms, usdmb;
	if (file.is_open())
	{
		while (std::getline(file, line))
		{
			std::istringstream iss(line);
			iss >> dij >> tel >> nev >> cim >> usdmin >> usdsms >> usdmb;
			ugyfel* temp1 = new ugyfel(tel, nev, cim, usdmin, usdsms, usdmb);
			if (dij == "sms")
			{
				lista * temp = new lista;
				temp->fo = temp1;
				temp->tar = sms;
				temp->kov = NULL;
				kezd = beszur(kezd, temp);
			}
			if (dij == "alap")
			{
				lista * temp = new lista;
				temp->fo = temp1;
				temp->tar = alap;
				temp->kov = NULL;
				kezd = beszur(kezd, temp);
			}
			if (dij == "net")
			{
				lista * temp = new lista;
				temp->fo = temp1;
				temp->tar = net;
				temp->kov = NULL;
				kezd = beszur(kezd, temp);
			}

		}
	}
	else { std::cout << "nem tal�lja a faljt"; }
	file.close();
	return kezd;
}