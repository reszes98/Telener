#pragma once

class tarifa  {
	 unsigned int alap_dij;//szamla alapdija
	 unsigned int free_min;//szamlaban foglalt lebeszelheto percek
	 unsigned int free_sms;//szamlaban foglalt felhasznalhato smsek
	 unsigned int free_mb;//szamlaban foglalt felhasznalhato mbok

	 unsigned int p_min;//szamlaban foglaltakon feluli telefonhivas percenkenti dija
	 unsigned int p_sms;// szamlaban foglaltakon feluli sms dij
	 unsigned int p_mb;// szamlaban foglaltakon feluli adat dij
	 
public:

	//konstr, dek
	//net 6000  0 perc,korl�tlan net, 0 sms, ut�na 55/perc 55/sms
	tarifa(unsigned int alap_dij= 0, unsigned int free_min = 0, unsigned int free_sms=0,  unsigned int free_mb = 0,
		unsigned int p_min = 0, unsigned int p_sms=0, unsigned int p_mb=0 )
		:alap_dij(alap_dij), free_min(free_min), free_sms(free_sms), free_mb(free_mb), p_min(p_min), p_sms(p_sms), p_mb(p_mb){}
	~tarifa() { }
	//setter
	void set_dij(unsigned int p) { alap_dij = p; }
	void set_sms(unsigned int p) { free_sms = p; }
	void set_mb(unsigned int p) { free_mb = p; }
	void set_min(unsigned int p) { free_min = p; }
	void set_psms(unsigned int p) { p_sms = p; }
	void set_pmb(unsigned int p) { p_mb = p; }
	void set_pmin(unsigned int p) { p_min = p; }
	//getter
	unsigned int get_dij() { return alap_dij; }
	unsigned int get_sms() { return free_sms; }
	unsigned int get_mb() { return free_mb; }
	unsigned int get_min() { return free_min; }
	unsigned int get_psms() { return p_sms; }
	unsigned int get_pmb() { return p_mb; }
	unsigned int get_pmin() { return p_min; }

};
