#pragma once
#include "ugyfel.hpp"
#include "tarifa.hpp"


struct lista {
	ugyfel* fo = NULL;
	tarifa* tar = NULL;
	lista* kov = NULL;
};


lista* beszur(lista* kezdo, lista*uj);


lista* keres(lista* kezdo, int keresett);


int sum(lista* a);


void kiir(lista* a);


lista* olvas(lista* kezd, tarifa* alap, tarifa* net, tarifa* sms);